package tests;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class Authorization {
	
	/*	@Test
		public void basicAuth()
		{
			
			baseURI = "https://postman-echo.com";

			given()
			.auth().basic("postman", "password")
			.contentType(ContentType.JSON)
			.accept(ContentType.JSON)
			
			.when()
			.get("/basic-auth")
			
			.then()
			.statusCode(200)
			.body("authenticated",equalTo(true))
			.log().all();
			
				
			
		}*/
		
		@Test
		public void bearerTokenAuth() {
			
			
			baseURI = "https://gorest.co.in";
			
			Response res = (Response)
					given()
			.contentType(ContentType.JSON)
			.accept(ContentType.JSON)
			.headers("Authorization","364c3f8da686b79462277d431b7df3956d0bb2d6de6b7e6ebbe23ceec5f17cb7")
			
			.when()
			.get("/public/v2/users");
			
			String name = res.jsonPath().get("x[1].id");
			System.out.println(name);
			
			String response = res.asPrettyString();
			System.out.println(response);
			
			
			
			
		}

}
