package tests;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;
import java.util.Map;

public class PostGetExamples {
	
	@Test
	public void test_1()
	{
		Response response = get("https://reqres.in/api/users?page=2");
		
		System.out.println(response.getStatusCode());
		System.out.println(response.getTime());
		System.out.println(response.getBody().asString());
		System.out.println(response.getContentType());
		
		int statusCode = response.getStatusCode();
		
		Assert.assertEquals(statusCode, 200);
		
	}
	
	//@Test
	public void test2()
	{
		
		baseURI = "https://reqres.in/api";

		given()
			.get("/users?page=2")
		.then()
			.statusCode(200)
			.body("data[1].id", equalTo(8))
			.log().all();
		
	}
	
	//@Test
	public void test_Get() {
		
		baseURI = "https://reqres.in/api";
		
		given()
		.get("/users?page=2")
		.then()
		.statusCode(200)
		.body("data[0].first_name", equalTo("Michael"))
		.body("data.first_name",hasItems("Michael","Lindsay"));
		
	}
	
	@Test
	public void test_Post() {
		
		Map<String,Object> data = new HashMap<String,Object>();
		
		
		
		//Data Formates
		
		//Way 1:
		/*data.put("name", "Manjesh");
		data.put("job", "Tester");
		
		System.out.println(data);*/
		
		//Way 2:
		/*JSONObject jsonData = new JSONObject(data);
		System.out.println(jsonData);*/
		
		//Way 3:
		
		JSONObject jsondata = new JSONObject();
		jsondata.put("name", "Manjesh");
		jsondata.put("job","Tester");
		System.out.println(jsondata.toJSONString());
		
		baseURI ="https://reqres.in/api";
		
		given()
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)		
		.body(jsondata.toJSONString()).
		
		when()
		.post("/users").
		
		then()
		.statusCode(201)
		.body("name", equalTo("Manjesh"))
		.log().all();
		
		
		
		
	}
	

}
