package tests;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;
import java.util.Map;

public class PutPatchDeleteExamples {
	
	@Test
	public void test_Put() {
		
		baseURI = "https://reqres.in";
		
		JSONObject jsondata = new JSONObject ();
		jsondata.put("name", "UserPut");
		jsondata.put("job", "UserTest");
		
		given()
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		.body(jsondata.toJSONString()).
		
		when()
		.put("/api/users/2").

		then()
		.statusCode(200)
		.body("name", equalTo("UserPut"))
		.log().all();
				
		
	}
	
	@Test
	public void test_Delete() {
		
		
		baseURI ="https://reqres.in/api";
		
		when()
		.delete("/users/2").
		
		then()
		.statusCode(204);
		
		
		
	}

}
