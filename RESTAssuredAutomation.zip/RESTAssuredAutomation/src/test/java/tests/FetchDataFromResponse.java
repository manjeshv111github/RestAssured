package tests;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;

import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import java.util.HashMap;
import java.util.Map;


public class FetchDataFromResponse {
	
		@Test
		public void test_Get(){
			
			baseURI = "https://reqres.in";
				
			Response res = 	(Response) 	given()
					.contentType(ContentType.JSON)
					.accept(ContentType.JSON)
									
			.when()
				.get("/api/users?page=2");
		
		for(int i=0;i<3;i++) {
			String str1=res.jsonPath().get("data["+i+"].first_name");
			System.out.println(str1);
					
			System.out.println(">>>>>>>>>>>>>>>>>>> "+res.asPrettyString());
					
			}
		}

	
	
}
