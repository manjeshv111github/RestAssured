package tests;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class FolderCreation {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
		String date = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(Calendar.getInstance().getTime());
		
		System.out.println(date);
		
		String dirName = "C:/Users/ManjeshaV/Desktop/"+date;
		
		//File f = new File (dirName);
		
		//f.mkdir();
		
		Path sourcePath = Paths.get("C:\\Users\\ManjeshaV\\Desktop\\new.txt");
        Path destinationPath = Paths.get(dirName);
        Files.copy(sourcePath, destinationPath);
		
		
		
	}

}
